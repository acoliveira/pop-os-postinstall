<!-- ------------------------------------------------------------------------------------
     ------------------------------------------------------------------------------------->
<p align="center"><img src="Teleport-theme-Dark-red/default.svg" height="125px"><p>
  <h1 align="center"> Teleport Theme for Plank </h1> 
<p align="center"> Teleport theme is a variation Dock for <a href="https://launchpad.net/plank">Plank Desktop</a> </p>

### Install:
* Make sure you already have Plank installed or run ``` sudo apt-get install plank```

```Shell
git clone https://github.com/horberlan/Teleport-theme.git
cd Teleport-theme/
sh install.sh 
```


### Examples:

* Dark Red Theme

<p align="center">
  <img src="dark-red-teleport-theme.gif">
<!--<img src="exemple-Dark-red.gif" width="800px"> -->
</p>
<br>

* Light Blue Theme

<p align="center">
  <img src="light-blues-teleport-theme.gif">
</p>

* Light Pink Theme

<p align="center">
  <img src="https://raw.githubusercontent.com/horberlan/Teleport-theme/main/Teleport-theme-Pink/pink-ex.gif">
</p>
